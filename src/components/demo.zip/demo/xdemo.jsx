import React, {Component} from "react";
class Demo extends Component{
    state={ }

    render(){

        return(
            <div>
            <div className="row mx-0 text-light">
                <div className="col-2 pl-3" style={{background:"#040440",height:"100vh"}}>
                <h5 className="pt-4">Dashborad</h5>

                <h6 className="mt-4 py-3 rounded pl-3" style={{background:"#2d2d69"}}>Dashborad</h6>
                <div className="">
                    <div className="my-4"><i class="fa-solid fa-table-columns mx-3"></i>Product <span className="float-right"><i class="fa-solid fa-chevron-right fa-xs"></i></span></div>
                    <div className="my-4"><i class="fa-solid fa-table-columns mx-3"></i>Customers <span className="float-right"><i class="fa-solid fa-chevron-right fa-xs"></i></span></div>
                    <div className="my-4"><i class="fa-solid fa-table-columns mx-3"></i>Income <span className="float-right"><i class="fa-solid fa-chevron-right fa-xs"></i></span></div>
                    <div className="my-4"><i class="fa-solid fa-table-columns mx-3"></i>Promote <span className="float-right"><i class="fa-solid fa-chevron-right fa-xs"></i></span></div>
                    <div className="my-4"><i class="fa-solid fa-table-columns mx-3"></i>Help <span className="float-right"><i class="fa-solid fa-chevron-right fa-xs"></i></span></div>

                    <div>
                        <div className=" rounded pl-5 py-1 mb-5" style={{background:"#2d2d69",position:"absolute",bottom:'0'}}>
                            <span className="pr-5">Vishal</span> 
                            <span className="float-right pl-5 pr-2"><i class="fa-solid fa-chevron-down fa-xs"></i></span>
                            <div><small>Project Manager</small></div>
                        </div>

                    </div>
                </div>

                </div>

                <div className="col-10" style={{background:"#f5f6f8"}}>

                    <div className="row bg-white rounded w-25 py-3 px-1 m-4">
                    <div className="col-5">
                        <img src="https://imageupload.io/ib/dVBrt5WrUbtnDZ2_1697365542.png" className="p-3" width="90px" style={{background:"#e0ffef",borderRadius:"50%"}} />
                    </div>
                    <div className="col-7 pl-0 text-dark">
                        <div className="text-secondary"> Earning</div>
                        <h3>&#36;198K</h3>
                        <div className="fw-bold"><span style={{color:"#46a872"}}><i class="fa-solid fa-arrow-up"></i>37.8%</span><span className="text-secondary">this month</span></div>
                    </div>
                       
                    </div>
                </div>
            </div>




            </div>
        )
    }

}
export default Demo;








